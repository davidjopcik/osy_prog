#ifndef VER_H
#define VER_H

#include <stdbool.h>

void verification(long S, long *weight, bool valid);

#endif