#ifndef GEN_H
#define GEN_H

void generatorNum(long S, int N, int binary);

#endif